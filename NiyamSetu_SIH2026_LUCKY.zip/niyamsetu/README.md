# NiyamSetu — AI-Based Fake Identity & Document Screening System

**Smart India Hackathon 2026 · Problem Statement ID: 26188**  
**Problem title:** AI-Based Fake Identity & Document Screening System  
**Ministry:** Ministry of Home Affairs  
**Category:** Software · Miscellaneous

> **Safety and scope:** This is an educational SIH prototype for synthetic/test documents. It provides decision support only. It is not an official identity-verification service and must not be used to make a real border, immigration, law-enforcement, or eligibility decision. Every case requires a trained human officer's review.

## Problem summary
Border checkpoints process large volumes of passports, visas, identity cards, permits, and travel authorizations. Manual document checking is time-consuming and can miss altered or inconsistent information. The proposed system combines OCR, document consistency checks, tampering indicators, face-image comparison, and an explainable risk report to support—not replace—an authorized officer.

## Solution overview
NiyamSetu is a web application with a React/Vite frontend and FastAPI backend. An authenticated user creates a screening case, uploads a document image and optional selfie, runs the analysis pipeline, reviews the extracted fields and indicators, records a human decision, downloads a PDF report, and checks evidence hashes and the audit trail.

## Features
- Email/password registration and login; first registered account is assigned the admin role, subsequent accounts are officers.
- Case creation and per-user case access controls.
- JPEG/PNG upload validation (8 MB limit) and SHA-256 file hashes.
- Tesseract OCR and ICAO 9303 TD3 passport MRZ parsing/check digits.
- Image-quality checks and baseline Error Level Analysis (ELA) tampering indicator.
- OpenCV Haar face detection and basic image correlation for experimental similarity only.
- Explainable risk factors and recommended workflow; not an automated final decision.
- Human review with accept/reject/escalate decision and remarks.
- PDF screening report, evidence-hash verification endpoint, and hash-chained audit log.
- Dashboard summary and recent screening list.

## Screens
1. Landing page
2. Login / sign-up
3. Dashboard and recent screenings
4. New screening upload
5. Case results, validation, risk factors, officer review, and audit trail
6. Evidence SHA-256 verification

The uploaded bright browser prototype is preserved at `prototype/SIH_26188_Bright_UI_Prototype.html`. It is a separate standalone browser demo and is not the React frontend used by the full-stack app.

## Tech stack
- Frontend: React 18, Vite, React Router, Tailwind CSS 4, Three.js / React Three Fiber, Lucide React
- Backend: Python, FastAPI, SQLAlchemy, Pydantic, JWT (`python-jose`), bcrypt
- Image/OCR: OpenCV, NumPy, Tesseract OCR, pytesseract
- Reports: ReportLab
- Database: SQLite by default; PostgreSQL through Docker Compose
- Tests: pytest, httpx

## Architecture
```text
Browser (React/Vite)
  | /api requests (Vite proxy in development)
  v
FastAPI REST API
  |-- Auth: password hash + short-lived JWT
  |-- SQLAlchemy: users, cases, screening results, audit records
  |-- File storage: uploaded images and ELA evidence
  |-- Analysis pipeline: OCR/MRZ + quality + ELA + baseline face comparison
  |-- PDF report + evidence hash verification
  v
SQLite (local) or PostgreSQL (Docker Compose)
```

## Requirements
- Python 3.10+
- Node.js 18+ and npm
- Tesseract OCR installed on the operating system for OCR extraction
- For Docker mode: Docker Engine and Docker Compose

### Install and run locally

**1. Configure environment**

From the repository root:

```bash
cp .env.example .env
```

Change `SECRET_KEY` to a long random secret before using anything beyond local synthetic-data testing. For local runs, export the values in `.env` in your shell (or set them in your terminal); Docker Compose reads `.env` automatically. If no `SECRET_KEY` is set, the backend creates a random per-process key and existing tokens stop working after a restart.

**2. Start the backend**

Linux/macOS:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Windows PowerShell:
```powershell
cd backend
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API docs: http://localhost:8000/docs

Install Tesseract separately. On Ubuntu/Debian: `sudo apt-get install tesseract-ocr`. On Windows, install a Tesseract build and ensure `tesseract.exe` is on PATH.

**3. Start the frontend in a second terminal**
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. Vite proxies `/api` requests to `http://localhost:8000`.

### Run with Docker Compose
From the repository root:
```bash
cp .env.example .env
# Edit POSTGRES_PASSWORD and SECRET_KEY in .env
docker compose up --build
```
Open http://localhost:5173; API docs are at http://localhost:8000/docs. The compose file uses PostgreSQL and persistent volumes.

### Tests
```bash
cd backend
pytest -q
```

### Screenshots
Add screenshots in `docs/screenshots/` and update this section before submission:
- `docs/screenshots/landing.png`
- `docs/screenshots/dashboard.png`
- `docs/screenshots/screening-results.png`

## Team
- **Team name:** [Replace with your SIH team name]
- **Team leader:** [Replace with name]
- **Members:** [Replace with all team members and roles]
- **Institute:** LNCT, Bhopal [confirm before submission]

## Known limitations and future scope
- ELA is a baseline heuristic, not a trained forensic detector; compression and image quality can trigger false positives/negatives.
- Face matching uses Haar face detection plus grayscale correlation. It is not ArcFace/FaceNet, not liveness detection, and not proof of identity.
- MRZ support targets ICAO TD3 passports. Other document types may not have an MRZ and need separate parsers/rules.
- No authorized government database or watchlist is connected; the UI explicitly reports the watchlist as not configured.
- The audit trail is a local hash-chained database ledger, not a blockchain or a tamper-proof external service.
- Add trained and independently evaluated models, liveness/PAD, perspective correction, role management, migrations, production-grade rate limiting, retention controls, encryption at rest, monitoring, and approved integrations only after legal/security review.
- Evaluate accuracy, false positives/negatives, demographic performance, and operational impact before any real-world use.

## API overview
- `POST /api/auth/register`, `POST /api/auth/login`
- `POST /api/screenings`, `GET /api/screenings`
- `POST /api/screenings/{id}/documents`, `POST /api/screenings/{id}/selfie`
- `POST /api/screenings/{id}/analyze`
- `GET /api/screenings/{id}/results`, `GET /api/screenings/{id}/report`
- `POST /api/screenings/{id}/review`
- `GET /api/audit/{id}`, `POST /api/evidence/verify`
- `GET /api/dashboard/summary`

## GitHub upload
See the Git commands provided with this package. Do not commit `.env`, real identity documents, selfies, access tokens, or sensitive logs.
