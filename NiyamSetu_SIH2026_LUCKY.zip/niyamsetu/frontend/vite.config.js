import {defineConfig} from "vite";import react from "@vitejs/plugin-react";import tw from "@tailwindcss/vite"
export default defineConfig({plugins:[react(),tw()],server:{proxy:{"/api":process.env.API||"http://localhost:8000"}}})
