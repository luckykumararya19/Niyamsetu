import {useState,useEffect,useRef} from "react"
import {BrowserRouter,Routes,Route,Link,Navigate,useNavigate,useParams} from "react-router-dom"
import {Canvas,useFrame} from "@react-three/fiber"
import {ShieldCheck} from "lucide-react"
const api=async(p,o={})=>{const t=localStorage.t,r=await fetch("/api"+p,{method:o.method,body:o.json?JSON.stringify(o.json):o.body,headers:{...(t&&{Authorization:"Bearer "+t}),...(o.json&&{"Content-Type":"application/json"})}})
 if(!r.ok){if(r.status==401&&t){localStorage.removeItem("t")};throw new Error((await r.json().catch(()=>({}))).detail||r.statusText)}
 return o.blob?r.blob():r.json()}
function Orb(){const r=useRef();useFrame((_,d)=>{r.current.rotation.y+=d*.4;r.current.rotation.x+=d*.15})
 return <mesh ref={r}><icosahedronGeometry args={[1.7,1]}/><meshStandardMaterial color="#22d3ee" wireframe/></mesh>}
const Shell=({children})=>{if(!localStorage.t)return <Navigate to="/login"/>
 return <div><nav className="flex gap-4 p-4 border-b border-[#28407a] items-center"><ShieldCheck className="text-cyan-400"/><b>NiyamSetu</b><Link to="/dashboard">Dashboard</Link><Link to="/new">New screening</Link><Link to="/verify">Verify evidence</Link>
 <button className="ml-auto" onClick={()=>{localStorage.removeItem("t");location="/"}}>Logout</button></nav><main className="max-w-4xl mx-auto p-4">{children}</main></div>}
const Landing=()=><div className="h-screen relative"><Canvas className="!absolute inset-0"><ambientLight/><pointLight position={[4,4,4]}/><Orb/></Canvas>
 <div className="relative text-center pt-24"><h1 className="text-5xl font-bold">NiyamSetu</h1><p className="mt-3 text-slate-300">AI-assisted fake identity &amp; document screening — decision support with human review</p>
 <div className="mt-6 flex gap-3 justify-center"><Link className="b" to="/login">Login</Link><Link className="b" to="/signup">Sign up</Link></div></div></div>
function Auth({reg}){const[e,setE]=useState(""),[p,setP]=useState(""),[er,setEr]=useState(""),n=useNavigate()
 const go=async ev=>{ev.preventDefault();try{if(reg)await api("/auth/register",{method:"POST",json:{email:e,password:p}});const r=await api("/auth/login",{method:"POST",json:{email:e,password:p}});localStorage.t=r.token;n("/dashboard")}catch(x){setEr(x.message)}}
 return <form onSubmit={go} className="card max-w-sm mx-auto mt-24 space-y-3"><h2 className="text-xl">{reg?"Sign up":"Login"}</h2><input placeholder="Email" value={e} onChange={x=>setE(x.target.value)}/><input type="password" placeholder="Password (min 8)" value={p} onChange={x=>setP(x.target.value)}/>
 {er&&<p role="alert" className="text-red-400">{er}</p>}<button className="b w-full">{reg?"Create account":"Login"}</button></form>}
function Dash(){const[s,setS]=useState(),[l,setL]=useState([]);useEffect(()=>{api("/dashboard/summary").then(setS).catch(()=>{});api("/screenings").then(setL).catch(()=>{})},[])
 if(!s)return <p>Loading…</p>
 return <div><div className="grid grid-cols-2 md:grid-cols-4 gap-3">{Object.entries(s).map(([k,v])=><div className="card" key={k}><div className="text-2xl">{v}</div><div className="text-xs text-slate-400">{k.replaceAll("_"," ")}</div></div>)}</div>
 <h3 className="mt-6 mb-2">Recent screenings</h3>{l.length?l.map(c=><Link key={c.id} to={"/case/"+c.id} className="card block mb-2">#{c.id} — {c.level||"not analyzed"} ({c.risk??"-"}) — {c.status}</Link>):<p className="text-slate-400">No screenings yet.</p>}</div>}
function New(){const[d,setD]=useState(),[f,setF]=useState(),[er,setEr]=useState(""),[b,setB]=useState(false),n=useNavigate()
 const go=async()=>{setB(true);setEr("");try{const{id}=await api("/screenings",{method:"POST"});for(const[k,x]of[["documents",d],["selfie",f]]){if(!x)continue;const fd=new FormData();fd.append("file",x);await api(`/screenings/${id}/${k}`,{method:"POST",body:fd})}
 await api(`/screenings/${id}/analyze`,{method:"POST"});n("/case/"+id)}catch(x){setEr(x.message);setB(false)}}
 return <div className="card space-y-3"><h2>New screening (use synthetic documents only)</h2><label>Passport image (JPG/PNG ≤ 8MB)<input type="file" accept="image/jpeg,image/png" onChange={x=>setD(x.target.files[0])}/></label>
 <label>Selfie (optional)<input type="file" accept="image/jpeg,image/png" onChange={x=>setF(x.target.files[0])}/></label>{er&&<p role="alert" className="text-red-400">{er}</p>}<button className="b" disabled={!d||b} onClick={go}>{b?"Processing…":"Upload & analyze"}</button></div>}
function Case(){const{id}=useParams(),[r,setR]=useState(),[a,setA]=useState(),[d,setD]=useState("accept"),[m,setM]=useState(""),[er,setEr]=useState("")
 const load=()=>{api(`/screenings/${id}/results`).then(setR).catch(x=>setEr(x.message));api(`/audit/${id}`).then(setA).catch(()=>{})};useEffect(load,[id])
 const rev=async()=>{try{await api(`/screenings/${id}/review`,{method:"POST",json:{decision:d,remarks:m}});setEr("");load()}catch(x){setEr(x.message)}}
 const pdf=async()=>window.open(URL.createObjectURL(await api(`/screenings/${id}/report`,{blob:1})))
 if(er&&!r)return <p className="text-red-400">{er}</p>;if(!r)return <p>Loading…</p>;const x=r.result||{}
 return <div className="space-y-3"><div className="card"><div className="text-4xl">{r.risk}/100 <span className="text-lg">{r.level}</span></div><p>{x.action}</p><button className="b mt-2" onClick={pdf}>Download PDF</button></div>
 <div className="card"><h3>Extracted fields</h3><pre className="text-xs">{JSON.stringify(x.fields,null,1)||"No MRZ extracted"}</pre></div>
 <div className="card"><h3>Validation (verified failures vs AI indicators)</h3>{x.validation?.map((v,i)=><div key={i}>{v.ok?"✅":"❌"} {v.rule} <i className="text-xs text-slate-400">[{v.kind}]</i></div>)}</div>
 <div className="card"><h3>Risk factors</h3>{x.factors?.map(f=><div key={f.name}>+{f.points} {f.why}</div>)}<p className="text-xs mt-2 text-slate-400">Watchlist: {x.watchlist}</p></div>
 <div className="card"><h3>Tamper indicator — {x.tamper?.model}: {x.tamper?.score}</h3><p className="text-xs text-amber-300">Baseline heuristic; not a production forgery detector.</p></div>
 <div className="card"><h3>Face: {x.face?.state} {x.face?.similarity}</h3><p className="text-xs text-amber-300">{x.face?.note}</p></div>
 <div className="card space-y-2"><h3>Officer review {r.decision&&`— ${r.decision}`}</h3><select value={d} onChange={e=>setD(e.target.value)}><option>accept</option><option>reject</option><option>escalate</option></select>
 <textarea placeholder="Reason / remarks" value={m} onChange={e=>setM(e.target.value)}/>{er&&<p className="text-red-400">{er}</p>}<button className="b" onClick={rev}>Record decision</button></div>
 <div className="card"><h3>Audit trail — chain {a?.chain_valid?"valid ✅":"BROKEN ❌"}</h3>{a?.events.map((e,i)=><div key={i} className="text-xs">{e.ts} {e.event} <code>{e.hash.slice(0,12)}</code></div>)}</div></div>}
function Verify(){const[o,setO]=useState()
 return <div className="card space-y-2"><h2>Evidence integrity check (SHA-256)</h2><input type="file" onChange={async e=>{const fd=new FormData();fd.append("file",e.target.files[0]);setO(await api("/evidence/verify",{method:"POST",body:fd}).catch(x=>({error:x.message})))}}/>
 {o&&<pre className="text-xs">{JSON.stringify(o,null,1)}</pre>}</div>}
export default()=><BrowserRouter><Routes><Route path="/" element={<Landing/>}/><Route path="/login" element={<Auth/>}/><Route path="/signup" element={<Auth reg/>}/>
 <Route path="/dashboard" element={<Shell><Dash/></Shell>}/><Route path="/new" element={<Shell><New/></Shell>}/><Route path="/case/:id" element={<Shell><Case/></Shell>}/><Route path="/verify" element={<Shell><Verify/></Shell>}/></Routes></BrowserRouter>
