from app.pipeline import cd,parse_mrz
A="P<UTOERIKSSON<<ANNA<MARIA<<<<<<<<<<<<<<<<<<<";B="L898902C36UTO7408122F1204159ZE184226B<<<<<10"
def test_check_digits():assert cd("L898902C3")=="6" and cd("740812")=="2" and cd("120415")=="9"
def test_mrz():
    f,c=parse_mrz(A+"\n"+B);assert f["number"]=="L898902C3" and all(c.values())
def test_tampered_mrz():
    _,c=parse_mrz(A+"\n"+B.replace("7408122","7408123"));assert not c["dob"]
