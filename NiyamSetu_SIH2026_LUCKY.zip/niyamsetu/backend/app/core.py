import os,datetime as dt,secrets
from sqlalchemy import *
from sqlalchemy.orm import declarative_base,sessionmaker
DB=os.getenv("DATABASE_URL","sqlite:///./niyam.db")
SECRET=os.getenv("SECRET_KEY") or secrets.token_urlsafe(32)
DATA=os.getenv("DATA_DIR","./data");MAX=8*1024*1024
eng=create_engine(DB,connect_args={"check_same_thread":False} if DB.startswith("sqlite") else {})
S=sessionmaker(eng);Base=declarative_base()
class User(Base):__tablename__="users";id=Column(Integer,primary_key=True);email=Column(String,unique=True,index=True);pw=Column(String);role=Column(String,default="officer")
class Case(Base):
    __tablename__="cases";id=Column(Integer,primary_key=True);owner=Column(Integer,ForeignKey("users.id"),index=True)
    status=Column(String,default="created");doc=Column(String);selfie=Column(String);result=Column(JSON)
    risk=Column(Integer);level=Column(String);decision=Column(String);remarks=Column(Text);reviewer=Column(Integer)
    created=Column(DateTime,default=dt.datetime.utcnow)
class Audit(Base):
    __tablename__="audit";id=Column(Integer,primary_key=True);case_id=Column(Integer,index=True);event=Column(String)
    data=Column(JSON);ts=Column(String);prev=Column(String);hash=Column(String)
Base.metadata.create_all(eng)
