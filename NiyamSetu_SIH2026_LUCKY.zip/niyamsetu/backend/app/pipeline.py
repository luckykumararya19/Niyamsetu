import re,datetime as dt,cv2,numpy as np
try:import pytesseract
except Exception:pytesseract=None
def cd(s):
    t=0
    for i,c in enumerate(s):t+=(int(c) if c.isdigit() else ord(c)-55 if c.isalpha() else 0)*[7,3,1][i%3]
    return str(t%10)
def parse_mrz(txt):  # ICAO 9303 TD3 (passport)
    L=[re.sub(r"\s","",l) for l in txt.splitlines()];L=[l for l in L if len(l)>=40 and "<" in l]
    if len(L)<2:return None,None
    a,b=L[-2][:44].ljust(44,"<"),L[-1][:44].ljust(44,"<")
    f={"name":a[5:].replace("<<"," ").replace("<"," ").strip(),"number":b[:9].strip("<"),"nationality":b[10:13],"dob":b[13:19],"sex":b[20],"expiry":b[21:27]}
    c={"number":cd(b[:9])==b[9],"dob":cd(b[13:19])==b[19],"expiry":cd(b[21:27])==b[27],"composite":cd(b[:10]+b[13:20]+b[21:43])==b[43]}
    return f,c
def dte(s,future=False):
    try:
        y=int(s[:2]);yr=2000+y if future or y<=dt.date.today().year%100 else 1900+y
        return dt.date(yr,int(s[2:4]),int(s[4:6]))
    except Exception:return None
C=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
def face(img):
    g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY);f=C.detectMultiScale(g,1.1,5)
    if len(f)==0:return None
    x,y,w,h=max(f,key=lambda r:r[2]*r[3]);return cv2.resize(g[y:y+h,x:x+w],(96,96))
def ela(img,out):  # BASELINE error-level analysis, NOT a trained forgery detector
    _,e=cv2.imencode(".jpg",img,[cv2.IMWRITE_JPEG_QUALITY,90]);d=cv2.absdiff(img,cv2.imdecode(e,1)).max(axis=2)
    cv2.imwrite(out,np.clip(d*15,0,255).astype("uint8"));return round(min(1,float(np.percentile(d,99.5))/50),3)
def analyze(doc,selfie,out):
    img=cv2.imread(doc);g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY);h,w=g.shape;blur=float(cv2.Laplacian(g,cv2.CV_64F).var())
    q={"blur":round(blur,1),"width":w,"height":h,"ok":blur>=60 and w>=600}
    txt="";ocr=True
    try:txt=pytesseract.image_to_string(cv2.createCLAHE(2.0,(8,8)).apply(g),config="--psm 6")
    except Exception:ocr=False
    f,c=parse_mrz(txt);V=[];F=[]
    def v(rule,ok,kind="verified"):
        V.append({"rule":rule,"ok":ok,"kind":kind})
    if not ocr:v("OCR engine available (install Tesseract)",False)
    elif f is None:v("MRZ readable",False);F.append(("missing_mrz",20,"MRZ not found/readable (not all documents have one)"))
    else:
        v("MRZ readable",True)
        for k,ok in c.items():
            v(f"MRZ check digit: {k}",ok)
            if not ok:F.append(("mrz_check_"+k,10,f"ICAO check digit failed: {k}"))
        e,b=dte(f["expiry"],True),dte(f["dob"])
        v("Valid expiry date",e is not None);v("Valid date of birth",b is not None)
        if e is None or b is None:F.append(("bad_date",15,"Unparseable date in MRZ"))
        if e:
            v("Document not expired",e>=dt.date.today())
            if e<dt.date.today():F.append(("expired",25,"Document is expired"))
    if not q["ok"]:F.append(("quality",15,"Low image quality — request recapture"))
    t=ela(img,out+"/ela.png")
    v("Baseline ELA tamper indicator below threshold",t<0.5,"ai_indicator")
    F.append(("tamper_indicator",round(30*t),"Baseline ELA score (untrained heuristic)")) if t>=0.3 else None
    fs={"state":"no_selfie","similarity":None}
    if selfie:
        a,b=face(img),face(cv2.imread(selfie))
        if a is None or b is None:fs={"state":"no_face_detected","similarity":None};F.append(("face_missing",15,"Face not detected in document or selfie"))
        else:
            s=float(cv2.matchTemplate(a,b,cv2.TM_CCOEFF_NORMED)[0][0]);fs={"state":"review_required","similarity":round(s,3)}
            if s<0.2:F.append(("face_low_similarity",25,"Low baseline face similarity"))
    fs["note"]="Baseline Haar+correlation. NOT ArcFace; not proof of identity. Always needs officer review."
    score=min(100,sum(p for _,p,_ in F));lvl="Low" if score<25 else "Medium" if score<50 else "High"
    if lvl=="Low" and (not q["ok"] or not ocr or fs["state"]!="review_required"):lvl="Review Required"
    return {"quality":q,"ocr_available":ocr,"fields":f,"mrz_checks":c,"validation":V,"tamper":{"score":t,"model":"baseline-ELA (replaceable, untrained)"},
      "face":fs,"factors":[{"name":n,"points":p,"why":w} for n,p,w in F],"watchlist":"not_configured (not treated as clean)",
      "action":{"Low":"Proceed with standard officer review","Medium":"Detailed officer review","High":"Escalate","Review Required":"Manual review / recapture"}[lvl]},score,lvl
