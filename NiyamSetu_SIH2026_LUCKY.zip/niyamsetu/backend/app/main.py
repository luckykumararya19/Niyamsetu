import os,io,json,time,hashlib,datetime as dt,bcrypt,cv2,numpy as np
from fastapi import FastAPI,Depends,HTTPException,UploadFile,File,Header,Request
from fastapi.responses import FileResponse,Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel,Field
from jose import jwt
from .core import *
from .pipeline import analyze
app=FastAPI(title="NiyamSetu API");app.add_middleware(CORSMiddleware,allow_origins=os.getenv("CORS","http://localhost:5173").split(","),allow_methods=["*"],allow_headers=["*"])
def D():
    with S() as s:yield s
class Cred(BaseModel):email:str=Field(min_length=5,max_length=120);password:str=Field(min_length=8,max_length=100)
class Rev(BaseModel):decision:str=Field(pattern="^(accept|reject|escalate)$");remarks:str=Field(min_length=3,max_length=2000)
hits={}
def limit(k):
    t=time.time();h=[x for x in hits.get(k,[]) if t-x<60]+[t];hits[k]=h
    if len(h)>10:raise HTTPException(429,"Too many attempts")
def me(authorization:str=Header(None),db=Depends(D)):
    try:u=db.get(User,int(jwt.decode(authorization.split()[1],SECRET,algorithms=["HS256"])["sub"]))
    except Exception:raise HTTPException(401,"Invalid or expired token")
    if not u:raise HTTPException(401,"Invalid token")
    return u
def own(db,cid,u):
    c=db.get(Case,cid)
    if not c or (u.role!="admin" and c.owner!=u.id):raise HTTPException(404,"Case not found")
    return c
def sha(b):return hashlib.sha256(b).hexdigest()
def audit(db,cid,ev,data):  # local append-only hash-chained ledger (NOT a blockchain; adapter point)
    last=db.query(Audit).order_by(Audit.id.desc()).first();prev=last.hash if last else "0"*64;ts=dt.datetime.utcnow().isoformat()
    db.add(Audit(case_id=cid,event=ev,data=data,ts=ts,prev=prev,hash=sha(f"{prev}{cid}{ev}{json.dumps(data,sort_keys=True)}{ts}".encode())));db.commit()
def chain_ok(db):
    p="0"*64
    for a in db.query(Audit).order_by(Audit.id):
        if a.prev!=p or a.hash!=sha(f"{a.prev}{a.case_id}{a.event}{json.dumps(a.data,sort_keys=True)}{a.ts}".encode()):return False
        p=a.hash
    return True
@app.post("/api/auth/register",status_code=201)
def reg(c:Cred,db=Depends(D)):
    limit(c.email)
    if db.query(User).filter_by(email=c.email.lower()).first():raise HTTPException(409,"Email already registered")
    u=User(email=c.email.lower(),pw=bcrypt.hashpw(c.password.encode(),bcrypt.gensalt()).decode(),role="admin" if db.query(User).count()==0 else "officer")
    db.add(u);db.commit();return {"id":u.id,"role":u.role}
@app.post("/api/auth/login")
def login(c:Cred,db=Depends(D)):
    limit("l"+c.email);u=db.query(User).filter_by(email=c.email.lower()).first()
    if not u or not bcrypt.checkpw(c.password.encode(),u.pw.encode()):raise HTTPException(401,"Invalid credentials")
    return {"token":jwt.encode({"sub":str(u.id),"exp":dt.datetime.utcnow()+dt.timedelta(hours=2)},SECRET,algorithm="HS256"),"role":u.role}
@app.post("/api/screenings",status_code=201)
def new(u=Depends(me),db=Depends(D)):
    c=Case(owner=u.id);db.add(c);db.commit();audit(db,c.id,"case_created",{"by":u.id});return {"id":c.id}
def save(kind):
    def h(cid:int,file:UploadFile=File(...),u=Depends(me),db=Depends(D)):
        c=own(db,cid,u);b=file.file.read(MAX+1)
        if len(b)>MAX or file.content_type not in("image/jpeg","image/png"):raise HTTPException(415,"JPEG/PNG up to 8 MB only")
        if cv2.imdecode(np.frombuffer(b,np.uint8),1) is None:raise HTTPException(415,"Not a valid image")
        d=f"{DATA}/{cid}";os.makedirs(d,exist_ok=True);open(f"{d}/{kind}.img","wb").write(b);setattr(c,kind,f"{d}/{kind}.img")
        db.commit();audit(db,cid,f"{kind}_uploaded",{"sha256":sha(b)});return {"sha256":sha(b)}
    return h
app.post("/api/screenings/{cid}/documents",status_code=201)(save("doc"))
app.post("/api/screenings/{cid}/selfie",status_code=201)(save("selfie"))
@app.post("/api/screenings/{cid}/analyze")
def run(cid:int,u=Depends(me),db=Depends(D)):
    c=own(db,cid,u)
    if not c.doc:raise HTTPException(400,"Upload a document first")
    r,s,l=analyze(c.doc,c.selfie,os.path.dirname(c.doc))
    r["hashes"]={k:sha(open(p,"rb").read()) for k,p in(("doc",c.doc),("selfie",c.selfie)) if p}
    c.result,c.risk,c.level,c.status=r,s,l,"awaiting_review";db.commit();audit(db,cid,"analyzed",{"risk":s,"level":l});return {"risk":s,"level":l}
@app.get("/api/screenings/{cid}/status")
def st(cid:int,u=Depends(me),db=Depends(D)):return {"status":own(db,cid,u).status}
@app.get("/api/screenings/{cid}/results")
def res(cid:int,u=Depends(me),db=Depends(D)):
    c=own(db,cid,u);return {"id":c.id,"status":c.status,"risk":c.risk,"level":c.level,"result":c.result,"decision":c.decision,"remarks":c.remarks}
@app.get("/api/screenings/{cid}/evidence")
def ev(cid:int,u=Depends(me),db=Depends(D)):
    c=own(db,cid,u);p=os.path.join(os.path.dirname(c.doc or ""),"ela.png")
    if not os.path.exists(p):raise HTTPException(404,"No evidence yet")
    return FileResponse(p,media_type="image/png")
@app.post("/api/screenings/{cid}/review")
def review(cid:int,r:Rev,u=Depends(me),db=Depends(D)):
    c=own(db,cid,u)
    if c.status=="created":raise HTTPException(400,"Run analysis before review")
    c.decision,c.remarks,c.reviewer,c.status=r.decision,r.remarks,u.id,"reviewed";db.commit();audit(db,cid,"officer_review",{"by":u.id,"decision":r.decision,"remarks":r.remarks});return {"ok":True}
@app.get("/api/screenings")
def lst(u=Depends(me),db=Depends(D)):
    q=db.query(Case);q=q if u.role=="admin" else q.filter_by(owner=u.id)
    return [{"id":c.id,"status":c.status,"risk":c.risk,"level":c.level,"decision":c.decision,"created":c.created.isoformat()} for c in q.order_by(Case.id.desc()).limit(100)]
@app.get("/api/dashboard/summary")
def summ(u=Depends(me),db=Depends(D)):
    q=db.query(Case);cs=(q if u.role=="admin" else q.filter_by(owner=u.id)).all();rs=[c.result or {} for c in cs]
    return {"total":len(cs),"awaiting_review":sum(c.status=="awaiting_review" for c in cs),**{k:sum(c.level==k for c in cs) for k in("Low","Medium","High","Review Required")},
      "validation_failures":sum(any(not v["ok"] and v["kind"]=="verified" for v in r.get("validation",[])) for r in rs),
      "tamper_flags":sum(r.get("tamper",{}).get("score",0)>=.5 for r in rs)}
@app.get("/api/audit/{cid}")
def aud(cid:int,u=Depends(me),db=Depends(D)):
    own(db,cid,u);return {"chain_valid":chain_ok(db),"events":[{"event":a.event,"data":a.data,"ts":a.ts,"hash":a.hash} for a in db.query(Audit).filter_by(case_id=cid).order_by(Audit.id)]}
@app.post("/api/evidence/verify")
def ver(file:UploadFile=File(...),u=Depends(me),db=Depends(D)):
    h=sha(file.file.read(MAX+1));q=db.query(Case);q=q if u.role=="admin" else q.filter_by(owner=u.id)
    m=[{"case":c.id,"file":k} for c in q for k,v in (c.result or {}).get("hashes",{}).items() if v==h]
    return {"sha256":h,"match":bool(m),"matches":m}
@app.get("/api/screenings/{cid}/report")
def report(cid:int,u=Depends(me),db=Depends(D)):
    from reportlab.pdfgen import canvas
    c=own(db,cid,u);r=c.result or {};L=[("NiyamSetu Screening Report",16),(f"Case #{c.id}   Created {c.created}",10),("",8),("AI FINDINGS (decision support only)",12),(f"Risk {c.risk}/100 - {c.level}",10),(f"Action: {r.get('action')}",10)]
    L+=[(f" factor: {f['name']} +{f['points']} - {f['why']}",9) for f in r.get("factors",[])]+[(f" {'PASS' if v['ok'] else 'FAIL'} [{v['kind']}] {v['rule']}",9) for v in r.get("validation",[])]
    L+=[(f"Fields: {json.dumps(r.get('fields'))}",9),(f"Tamper: {r.get('tamper')}",9),(f"Face: {r.get('face')}",9),(f"Watchlist: {r.get('watchlist')}",9),("",8),("HUMAN DECISION",12),(f"{c.decision or 'PENDING'} - {c.remarks or ''}",10),("",8),("EVIDENCE",12),(f"Hashes: {r.get('hashes')}",8)]
    last=db.query(Audit).filter_by(case_id=cid).order_by(Audit.id.desc()).first();L.append((f"Audit head: {last.hash if last else '-'}",8))
    b=io.BytesIO();p=canvas.Canvas(b);y=800
    for t,s in L:
        for i in range(0,max(len(t),1),105):
            if y<50:p.showPage();y=800
            p.setFont("Helvetica",s);p.drawString(40,y,t[i:i+105]);y-=s+5
    p.save();audit(db,cid,"report_downloaded",{"by":u.id});return Response(b.getvalue(),media_type="application/pdf")
